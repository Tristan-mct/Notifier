#!/usr/bin/env python3
"""
Created on Fri Jul 17 09:09:48 2020.

@author: Tristan Muscat
"""
__version__ = "0.1.1"

from .notifbot import NotifBot
